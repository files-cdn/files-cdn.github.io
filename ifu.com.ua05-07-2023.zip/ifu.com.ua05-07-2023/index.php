<?php

/**
 * -=-=-=-=-=-=- -=-=-=-=-=-=- -=-=-=-=-=-=- -=-=-=-=-=-=- -=-=-=-=-=-=- -=-=-=-=-=-=- -=-=-=-=-=-=- -=-=-=-=-=-=-
 *
 * Костыльный редирект
 *
 * -=-=-=-=-=-=- -=-=-=-=-=-=- -=-=-=-=-=-=- -=-=-=-=-=-=- -=-=-=-=-=-=- -=-=-=-=-=-=- -=-=-=-=-=-=- -=-=-=-=-=-=-
 */

// Карта с игнором get параметров
$redirectLazyMap = [
];

// Карта строгого соответствия
$redirectStrictMap = [
    '/?lang=ua&s=&p=' => 'http://ifu.com.ua/',
    '/?s=7&p=s02' => 'http://ifu.com.ua/',
    '/?s=2&p=' => 'http://ifu.com.ua/',
    '/?s=' => 'http://ifu.com.ua/',
    '/?s=7&p=s01' => 'http://ifu.com.ua/',
    '/?s=2&p=s03' => 'http://ifu.com.ua/',
    '/?s=7' => 'http://ifu.com.ua/',
    '/?s=7&p=s03' => 'http://ifu.com.ua/',
    '/photo/2011/brochure.pdf' => 'http://ifu.com.ua/',
    '/?lang=fr&s=&p' => 'http://ifu.com.ua/',
    '/?s=10&p=s0' => 'http://ifu.com.ua/',
    '/wp-content/uploads/2013/04/concorde2.jpg' => 'http://ifu.com.ua/',
    '/французька-весна/' => 'http://ifu.com.ua/',
    '/?s=10&p=s01' => 'http://ifu.com.ua/',
    '/?lang=fr&s=7&p=s01' => 'http://ifu.com.ua/',
    '/?lang=ua' => 'http://ifu.com.ua/',
    '/?s=10&p=s01' => 'http://ifu.com.ua/',
    '/?s=10&p=s01-1' => 'http://ifu.com.ua/',
    '/?s=11&p=s1-4' => 'http://ifu.com.ua/',
    '/?s=7&p=s04' => 'http://ifu.com.ua/',
    '/?s=8&p' => 'http://ifu.com.ua/',
    '/?s=8&p' => 'http://ifu.com.ua/',
    '/Dossier_de_Candidature_Copernic_2006-2007.pdf' => 'http://ifu.com.ua/',
    '/Fiche_de_renseignement_bourses_sept_05.pdf' => 'http://ifu.com.ua/',
    '/Guide_2006-2007_de_letudiant_ukrainien.pdf' => 'http://ifu.com.ua/',
    '/Ukraine.doc' => 'http://ifu.com.ua/',
    '/dwnld/manuel_du_candidat TEF_aQ.pdf' => 'http://ifu.com.ua/',
    '/photo/2011/brochure.pdf' => 'http://ifu.com.ua/',
    '/photo/2011/broshura_himia_final.pdf' => 'http://ifu.com.ua/',
    '/?lang=fr&s=8&p=s02' => 'http://ifu.com.ua/',
    '/?lang=ua&amp;s=&amp;p=' => 'http://ifu.com.ua/',
    '/?lang=ua&amp;s=&p=' => 'http://ifu.com.ua/',
    '/?s=1&p=s02' => 'http://ifu.com.ua/',
    '/?s=11&p=s1' => 'http://ifu.com.ua/',
    '/?s=2' => 'http://ifu.com.ua/',
    '/?s=7&p=s16' => 'http://ifu.com.ua/',
    '/Guide_2006-2007_de_letudiant_ukrainien.pdf' => 'http://ifu.com.ua/',
    '/dwnld/Affiche_Festival_2009.doc' => 'http://ifu.com.ua/',
    '/dwnld/Printemps09.pdf' => 'http://ifu.com.ua/',
    '/dwnld/manuel_du_candidat TEF_aQ.pdf' => 'http://ifu.com.ua/',
    '/photo/2011/program2011_ukr_.png' => 'http://ifu.com.ua/',
];


// -=-=-=-=-=-=- -=-=-=-=-=-=- -=-=-=-=-=-=- -=-=-=-=-=-=- -=-=-=-=-=-=- -=-=-=-=-=-=- -=-=-=-=-=-=- -=-=-=-=-=-=-
$request = [
	'url' => '',
	'protocol' => 'http',
	'components' => []
];

if((!empty($_SERVER['HTTPS']) && ($_SERVER['HTTPS'] == 'on' || $_SERVER['HTTPS'] == 1)) ||
	(!empty($_SERVER['HTTP_X_FORWARDED_PROTOCOL']) && $_SERVER['HTTP_X_FORWARDED_PROTOCOL'] == 'https'))
	$request['protocol'] = 'https';

$request['url'] = "{$request['protocol']}://{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";
$request['components'] = @parse_url($request['url']);
if(!empty($request['components']['query']))
	parse_str($request['components']['query'], $request['components']['params']);

// Роутинг
if(!empty($redirectLazyMap[$request['components']['path']]))
{
	http_response_code(301);
	header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
	header('Expires: Sat, 26 Jul 1997 05:00:00 GMT');
	header("Location: {$redirectLazyMap[$request['components']['path']]}");
	$content = '';
}
else if(!empty($redirectStrictMap[$_SERVER['REQUEST_URI']]))
{
	http_response_code(301);
	header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
	header('Expires: Sat, 26 Jul 1997 05:00:00 GMT');
	header("Location: {$redirectStrictMap[$_SERVER['REQUEST_URI']]}");
	$content = '';
}
else if(in_array($_SERVER['REQUEST_URI'], ['/', '/index.html']) && is_readable(__DIR__.'/index2.php'))
	$content = @include(__DIR__.'/index2.php');
else
{
	http_response_code(404);
	$content = "<html>\n<head><title>404 Not Found</title></head>\n<body bgcolor=\"white\">\n<center><h1>404 Not Found</h1></center>\n<hr><center>nginx</center>\n</body>\n</html>\n<!-- a padding to disable MSIE and Chrome friendly error page -->\n<!-- a padding to disable MSIE and Chrome friendly error page -->\n<!-- a padding to disable MSIE and Chrome friendly error page -->\n<!-- a padding to disable MSIE and Chrome friendly error page -->\n<!-- a padding to disable MSIE and Chrome friendly error page -->\n<!-- a padding to disable MSIE and Chrome friendly error page -->\n";
}

exit($content);