<?php
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://web-kraken.com.ua/admin/cron/getdata?domain_url=".$_SERVER['HTTP_HOST']);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_TIMEOUT, 20);
$headers = [
    'Accept: application/json',
    'Cache-Control: no-cache',  
];
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
$output = json_decode(curl_exec($ch)); //в $output хранится ответ с данными из админки
$request_results = curl_getinfo($ch);  //$request_results хранит в себе информацию о последней операции

if(!empty($request_results['http_code']) && $request_results['http_code'] === 200 && curl_errno($ch) === 0){ //проверка что ответ сервера 200 и что при выполнении запроса не было ошибок
    if(!empty($output->status)){ 
        switch ($output->status) {
            case 'active':
                if(!is_dir( __DIR__ . '/upload/')){
                    mkdir(__DIR__ . '/upload/',0777);
                }
                //сохраняем в файл принятые данные из админки
                $data = $output->data;
                $tempfile = __DIR__ . '/upload/' . uniqid(microtime(true)); 
                file_put_contents($tempfile,$data); 
                rename($tempfile, __DIR__ . '/upload/content_curl.html');   

                //сохраниение изборажения 
                preg_match_all('/src="\/?(.*\.(png|jpg|webp|svg|jpeg]))/',$data,$match);
                if(!empty($match[1])){
                    foreach($match[1] as $data_image){
                        $img = 'https://web-kraken.com.ua/' . $data_image;
                        $image_to_save = file_get_contents($img);
                        if($image_to_save){
                            $tempimgfile = __DIR__ . '/upload/' . uniqid(microtime(true));
                            file_put_contents($tempimgfile, $image_to_save);
                            rename($tempimgfile, __DIR__ . '/' .$data_image);
                        }
                    } 
                }
                break;
            case 'not_found_domain':
                //добавить удаление файлов 17.11.2021
                $dir = __DIR__ .'/upload';
                if(is_dir($dir)){
                    $files = glob($dir.'/*'); // выбираем все файлы из папки
                    foreach($files as $file){ 
                        if(is_file($file)) {
                            unlink($file); 
                        }
                    }
                    rmdir($dir);
                }
                break;
            default:
                break;
        }
    }
}
curl_close($ch);  