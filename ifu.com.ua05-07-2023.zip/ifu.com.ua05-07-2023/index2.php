<!DOCTYPE html>
<html lang="ru-UA">
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      <title>Джокер Казино ⇒ Joker Casino Украина 🤑 Игровые автоматы Joker Win • Промокод</title>
      <meta name="description" content="Джокер Казино ❯❯❯ Игровые автоматы и слоты Joker Casino Украина 🤴 Регистрируйся с Промокодом в казино с бонусом до 150% от депозита 🥇 Обзор">
      <meta name="robots" content="index, follow">
      <meta name="robots" content="noarchive">
      <link rel="canonical" href="http://ifu.com.ua/" />
	   <link rel="alternate" href="http://ifu.com.ua/" hreflang="ru" />
	   <link rel="alternate" href="http://ifu.com.ua/" hreflang="ru-UA" />
	   <link rel="alternate" href="http://ifu.com.ua/ua/" hreflang="uk" />
	   <link rel="alternate" href="http://ifu.com.ua/ua/" hreflang="uk-UA" />
      <link rel="icon" type="image/png" sizes="16x16" href="wp-content/themes/images/favicon.png">
      <!-- <link rel="manifest" href="/manifest.json"> -->
      <meta name="msapplication-TileColor" content="#ffffff">
      <meta name="theme-color" content="#ffffff">
      <link rel='stylesheet' href='wp-content/themes/css/singlecas.css?v=1.2.1' type='text/css' media='all' />
      <link rel='stylesheet' href='wp-content/themes/css/resize.css?v=1.2.1' type='text/css' media='all' />
      <link href="wp-content/themes/css/cupon.css?v=1.2.1" rel="stylesheet">
      <!-- Global site tag (gtag.js) - Google Analytics -->
      <script async src="https://www.googletagmanager.com/gtag/js?id=UA-175480980-1"></script>
      <script>
         window.dataLayer = window.dataLayer || [];
         function gtag() { dataLayer.push(arguments); }
         gtag('js', new Date());

         gtag('config', 'UA-175480980-1');
      </script>
      <script type="application/ld+json">
         {
            "@context": "https://schema.org",
            "@type": "BreadcrumbList",
            "itemListElement": [ {
               "@type": "ListItem",
               "position": 1,
               "item": {
                     "@id": "http://ifu.com.ua/",
                     "name": "ifu.com.ua"
               }
            }, {
               "@type": "ListItem",
               "position": 2,
               "item": {
                     "@id": "http://ifu.com.ua/#bonus",
                     "name": " 🎰 Игровые автоматы 🦇 Joker Casino"
               }
            } ]
         }
      </script>
      <script type="application/ld+json">
          [{
              "@context":"https://schema.org",
              "@type":"SoftwareApplication",
              "name":"Joker Casino",
              "url":"http://ifu.com.ua/",
              "author":{
                  "@type":"Organization",
                  "name":"Joker Casino"
              },
              "description":"Игровые автоматы",
              "applicationCategory":"SoftwareApplication",
              "operatingSystem":"Android, IOS",
              "aggregateRating":{
                  "@type":"AggregateRating",
                  "worstRating":"1",
                  "bestRating":"5",
                  "ratingValue": "4.7",
                  "ratingCount": "23"
              },
              "image":"",
              "offers":{
                  "@type":"Offer",
                  "category":"free",
                  "price":0,
                  "priceCurrency":"UAH"
              }
          }]
      </script>
      <style>
         .dis{pointer-events:none;}.text-center{text-align:center;}html{scroll-behavior:smooth;}:target{scroll-margin-top:15px;}a, abbr, acronym, address, applet, article, aside, audio, b, big, blockquote, body, canvas, caption, center, cite, code, dd, del, details, dfn, div, dl, dt, em, embed, fieldset, figcaption, figure, footer, form, h1, h2, h3, h4, h5, h6, header, hgroup, html, i, iframe, img, ins, kbd, label, legend, li, mark, menu, nav, object, ol, output, p, pre, q, ruby, s, samp, section, small, span, strike, strong, sub, summary, sup, table, tbody, td, tfoot, th, thead, time, tr, tt, u, ul, var, video{ margin:0; padding:0; border:0; font-size:100%; font:inherit; vertical-align:baseline} :focus{ outline:0} article, aside, details, figcaption, figure, footer, header, hgroup, menu, nav, section{ display:block} body{ line-height:1} ol, ul{ padding:0 0 0 40px; line-height:1} blockquote, q{ quotes:none} blockquote:after, blockquote:before, q:after, q:before{ content:none} table{ border-collapse:collapse; border-spacing:0} input[type=search]::-webkit-search-cancel-button, input[type=search]::-webkit-search-decoration, input[type=search]::-webkit-search-results-button, input[type=search]::-webkit-search-results-decoration{ -webkit-appearance:none; -moz-appearance:none} input[type=search]{ -webkit-appearance:none; -moz-appearance:none; -webkit-box-sizing:content-box; -moz-box-sizing:content-box; box-sizing:content-box} textarea{ overflow:auto; vertical-align:top; resize:vertical} audio, canvas, video{ display:inline-block; max-width:100%} audio:not([controls]){ display:none; height:0} [hidden]{ display:none} html{ font-size:100%; -webkit-text-size-adjust:100%; -ms-text-size-adjust:100%} a:focus{ outline:thin dotted} a:active, a:hover{ outline:0} img{ border:0; -ms-interpolation-mode:bicubic} figure{ margin:0} form{ margin:0} fieldset{ border:1px solid silver; margin:0 2px; padding:.35em .625em .75em} legend{ border:0; padding:0; white-space:normal} button, input, select, textarea{ font-size:100%; margin:0; vertical-align:baseline} button, input{ line-height:normal} button, select{ text-transform:none} button, html input[type=button], input[type=reset], input[type=submit]{ -webkit-appearance:button; cursor:pointer} button[disabled], html input[disabled]{ cursor:default} input[type=checkbox], input[type=radio]{ box-sizing:border-box; padding:0} input[type=search]{ -webkit-appearance:textfield; -moz-box-sizing:content-box; -webkit-box-sizing:content-box; box-sizing:content-box} input[type=search]::-webkit-search-cancel-button, input[type=search]::-webkit-search-decoration{ -webkit-appearance:none} button::-moz-focus-inner, input::-moz-focus-inner{ border:0; padding:0} textarea{ overflow:auto; vertical-align:top} table{ border-collapse:collapse; border-spacing:0} button, html, input, select, textarea{ color:#222} img{ vertical-align:middle} fieldset{ border:0; margin:0; padding:0} textarea{ resize:vertical} .chromeframe{ margin:.2em 0; background:#ccc; color:#000; padding:.2em 0} @keyframes spin{ from{ transform:rotate(0)} to{ transform:rotate(360deg)}} .preloader{ animation-name:spin; animation-duration:800ms; animation-iteration-count:infinite; animation-timing-function:linear; text-align:center; z-index:999999; margin-top:45%} #page-preloader{ background:#793a46; width:100%; height:100%; position:fixed; left:0; top:0; z-index:99999; text-align:center} @media screen and (min-width:768px) and (max-width:4000px){ .preloader{ margin-top:15%}} body{ font-family:'Roboto Condensed', sans-serif; font-size:16px; color:#444} p>a{ color:#444; text-decoration:underline} ins{ margin:10px 0; font-size:18px; line-height:25px; text-decoration:none} a{ text-decoration:none} h1, h2, h3, h4{ text-transform:uppercase; font-family:'Roboto Condensed', sans-serif; font-weight:700} b, strong{ font-weight:700} em{ color:#d05; font-style:italic} .cc, .ccmob{ max-width:1186px; margin:0 auto} .clear{ clear:both} .content{ margin-left:auto; margin-right:auto; max-width:1186px; padding:0 35px} .uk-navbar-nav i{ display:block; margin:0 auto; width:26px; height:25px; margin-top:6px; background:url(wp-content/themes/images/icons.png) no-repeat} .uk-navbar-nav span{ color:#f2c525; margin-top:4px; font-size:12px; display:block; text-align:center; font-family:"Helvetica Neue", Helvetica, Arial, sans-serif} .uk-navbar-nav a{ border:1px solid transparent; border-bottom-width:0; box-sizing:border-box} .uk-navbar-nav>li>a:hover{ background:#9a0422} .vipi{ background-position:-74px 0 !important} .bonusui{ background-position:-24px 0 !important} .turnir{ background-position:1px 0 !important} .gamesi{ background-position:-50px 0 !important} .textlogo{ position:absolute; top:4px; left:50%; width:186px; height:93px; background-size:100%; margin-left:-48px; background:url(wp-content/themes/images/logo.png) no-repeat} .podpis{ position:absolute; top:55px; left:50%; height:10px; margin-left:-40px; font-size:18px !important; color:#793a46 !important; font-weight:700} .btn-orange{ box-shadow:0 4px 0 #904816, 0 5px 10px rgba(0, 0, 0, .35); background:#ec7724} .btn-green{ box-shadow:0 4px 0 #237919, 0 5px 10px rgba(0, 0, 0, .35); background:#35b925} .btnhead{ width:150px !important; margin-top:5px; margin-left:10px; cursor:pointer; border-radius:8px; color:#fff !important; text-transform:uppercase; height:40px; display:inline-block; line-height:42px; font-size:18px; transition:all .2s; text-align:center} .pointer{ cursor:pointer} header{ width:100%; background:#793a46; height:50px; line-height:60px; display:none; font-size:12px; z-index:9999;} .menu-btn{ background:0 0; position:absolute; top:0; line-height:40px; padding:0 10px 0 15px; color:#fff; border:0; font-size:1.7em; font-weight:700; cursor:pointer; outline:0; z-index:10000} .cross{ background:0 0; position:absolute; top:0; padding:10px 15px 0; color:#fff; border:0; font-size:3em; line-height:50px; font-weight:700; cursor:pointer; outline:0; z-index:100} .menu{ position:fixed; margin-top:80px; height:100vh; align-items:center; justify-content:center; background-color:#6f353f; width:270px; overflow-y:auto; z-index:999; -webkit-overflow-scrolling:touch; -webkit-transition:-webkit-transform .3s ease-in-out; transition:transform .3s ease-in-out; -ms-scroll-chaining:none; box-shadow:0 0 5px 2px rgba(0, 0, 0, .6); transform:translateX(-100%)} .menu_active{ transform:translateX(0)} .menu-list a{ color:#ccc; width:260px; float:left; padding:10px 0 10px 10px; box-shadow:inset 0 1px 0 rgba(255, 255, 255, .05); border-bottom:1px solid rgba(0, 0, 0, .3); text-shadow:0 1px 0 rgba(0, 0, 0, .5)} .menu-list a:hover{ background-color:#4c4c4c} .menu-list a:first-child{ border-top:1px solid rgba(0, 0, 0, .3)} .content{ transition:.5s; position:relative; z-index:0} .content_active{ transform:translateX(30%)} .mobilelogo{ width:190px; margin:0 auto; line-height:50px; text-align:center; font-size:18px; font-weight:700} .mobilelogo img{ margin-top:-3px} .mobilelogo a{ color:#fff; display:block; height:50px; width:90px; float:left} #header{ height:52px; top:0; left:0; background:#793a46; position:fixed; width:100%; z-index:9990} .noshad{ box-shadow:none} .uk-navbar-nav>li{ float:left} .uk-navbar-nav>li>a{ height:50px; width:100px; display:block; float:left; border-left:solid 1px #562a33; -webkit-transition:all .2s; transition:all .2s} .uk-breadcrumb{ padding:0; list-style:none; font-size:16px; color:#000; overflow:hidden; height:23px; margin-top:10px} .uk-breadcrumb a{ color:#793a46} .uk-breadcrumb>li{ display:inline-block} .uk-breadcrumb>li:nth-child(n+2):before{ content:"/"; display:inline-block; margin:0 8px} .uk-breadcrumb>li:not(.uk-active)>span{ color:#999} #footer{ background:#793a46; margin-top:-10px; height:150px} .copyright{ background:#3c141c; height:40px; color:#c1bebf; text-align:center; line-height:45px} .two-footer{ padding:10px 0} .footermenu{ display:block; width:33.3%; float:right} .footermenu ul{ list-style-type:none} .footermenu li a{ color:#f1c525; font-size:14px; line-height:26px} .aligncenter{ display:block; margin:0 auto;} .singcont img{ margin:15px auto; display:block;} img{ max-width:100%; height:auto;} .clearfix::after{ display:block; clear:both; content:" "} .dynamic-promo{ width:76%; margin-left:auto; margin-right:2%;} .tabs{ z-index:99; height:0px;} .tab{ position:relative; top:-175px; left:5px; width:20%; height:36px;} .mb-3{ margin-bottom:1rem;} .cas-but-tab{ height:32px; width:100%;} .m-auto{ margin:auto !important;} .mt-auto, .my-auto{ margin-top:auto !important;} .mr-auto, .mx-auto{ margin-right:auto !important;} .mb-auto, .my-auto{ margin-bottom:auto !important;} .ml-auto, .mx-auto{ margin-left:auto !important;} .playbutton{ padding:10px 3px; line-height:0px !important; color:#fff !important; text-transform:uppercase; border:1.7px solid #168212; border-radius:8px; margin-bottom:10px; font:inherit; cursor:grab; cursor:-webkit-grab; background-color:white;} .joker{ background-image:url(./logo/logo-joker.svg);} .vavada{ background-image:url(./logo/logo-vavada.svg);} .joycasino{ background-image:url(./logo/logo-joycasino-1.svg);} .pin-up{ background-image:url(./logo/logo_pinup.svg);} .promo-offer{ background-position:center; background-repeat:no-repeat; background-size:50%; background-origin:content-box;} #offers .item-tovars td{ width:100%;} .promo-action-code{ transform:scale(1.1); width:26%;} .promo-action-code div, .promo-action-code button{ margin:8px auto 0 auto;} .playbutton{ box-shadow:#111 0px 1px 0.1em;} .playbutton:hover{ box-shadow:#111 0px 2.5px 0.2em;} .item-tovars{ border:1.7px solid #168212;} .logocasino{ background-color:#fff; border-radius:8px; height:75px; display:flex;} .logocasino img{ margin:10px; width:90%; max-height:75px;} .promo-code{ min-width:148px; padding:0;} @media (max-width:1100px){ .dynamic-promo{ margin:0 auto; width:96%; padding-right:15px;} #offers .item-tovars td{ max-width:75%; margin-left:auto; min-height:160px; margin-top:-20px;} .promocode-blk__icon{ position:relative; vertical-align:middle; width:5%; top:-40px;} .promocode-blk__icon img{ position:absolute; left:16.5vw; top:45px;} .promo-action-code{ display:block; width:auto; padding:0px; transform:scale(1.2); margin-top:0px;} .promo-code{ height:50px; line-height:48px;} .promo-code-btn{ height:52px;} .tab{ top:-198px; left:30px;} .promo-offer{ background-size:75%;} #tooltiptext{ bottom:-45px; left:35%;} .progrescas, .ocenka{ max-height:135px; height:135px;}} @media (max-width:768px){ #pmcode{ margin-left:1px;} .tab{ position:relative; top:-26px; left:2%; display:inline-flex; width:24%; height:36px; margin:0 auto; justify-content:center; align-items:center;} #offers .item-tovars td{ max-width:100%; min-height:190px;} #offers tr.item-tovars{ min-height:165px; height:165px;} .playbutton{ border:1.7px solid #168212; background-color:white;} .promo-action-code{ transform:scale(1.2); margin-top:6px;} .promo-offer{ background-size:80%;}} @media (max-width:500px){ .tab{ top:-26px; width:23%;} #tooltiptext{ bottom:-28px; left:28%;} #offers .item-tovars td{ max-width:100%; margin-top:-8px;} .promo-offer{ background-size:95%;} .item-tovars{ padding:9px 9px 9px 9px;} .progrescas, .ocenka{ max-height:151px; height:151px; overflow:hidden;} .promo-action-code{ margin-top:-10px;} #singlecas h1{ font-size:16px;} #post-ratings-2864{ display:none;} #tooltiptext::after{ display:none;}} @media (max-width:390px){ .promo-action-code{ transform:scale(.9); margin-top:-10px; min-width:185px;} .progrescas, .ocenka{ max-height:173px; height:173px; overflow:hidden;} #tooltiptext{ bottom:-31px; left:20%;} #singlecas h1{ font-size:13px; margin-top:-5px;}} @media (max-width:320px){ .progrescas, .ocenka{ max-height:190px; height:190px; overflow:hidden;} #offers tr.item-tovars{ height:190px;}}th{font-weight:bold;}
      </style>
   </head>
			<body>
      <!-- <div id="header" class="hidemobile"><div class="cc"><div class="button-block"><span class="btnhead btn-green"><a href="https://gotoaddr.com/go/d5be11f7e318426beacae4242aaa9b3e365b64d1eb0a0b0b/" target="_blank" rel="nofollow" class="white">РЕГИСТРАЦИЯ </a></span><span class="btnhead btn-orange"><a href="https://gotoaddr.com/go/d5be11f7e318426beacae4242aaa9b3e365b64d1eb0a0b0b/" target="_blank" rel="nofollow" class="white">ВХОД </a></span></div></div></div> -->
      <!-- <header class="shovmobile hidesctop"><span class="pointer mobibtn btn btn-green"><a href="https://gotoaddr.com/go/d5be11f7e318426beacae4242aaa9b3e365b64d1eb0a0b0b/" target="_blank" rel="nofollow" class="white">РЕГИСТРАЦИЯ </a></span><span class="pointer mobibtn btn btn-orange"><a href="https://gotoaddr.com/go/d5be11f7e318426beacae4242aaa9b3e365b64d1eb0a0b0b/" target="_blank" rel="nofollow" class="white">ВХОД </a></span></header> -->
				<div id="singlecas" class="ccmob">
					<h1>Обзор сайта и игровых автоматов Joker Casino</h1>
					<!--? Dynamic content -->
					<!-- ! Joker Casino, vavada, joycasino, pin-up -->
					<div class="head-cas-block">
						<div class="container">
							<div class="row">
								<div id="offers" class="tab_content col">
									<!--? Joker Casino -->
									<div class="tab_item">
										<div class="logocasino mb-3" style="margin-top: 25px;">
											<img src="./logo/logo-joker.svg" alt="Онлайн казино Joker" width="342" height="210" class="mx-auto attachment-attachment-gamelist size-attachment-gamelist wp-post-image" style="margin: 0 10px; transform: scale(0.85);">
										</div>
										<div class="progrescas">
											<span>Рейтинг посетителей: <b>76%</b></span>
											<div class="progress">
												<div class="bar" style="width:76%"></div>
											</div>
											<span>Всего голосов: <b>29</b></span>
											<span> Голосуй за <b>Joker Casino</b>
												<span id="post-ratings-2864" class="post-ratings" data-nonce="400efd0efa">
													<img id="rating_2864_1" src="wp-content/plugins/wp-postratings/images/stars_flat_png_/rating_on.png" alt="Звёзд: 1" title="Звёзд: 1" style="cursor: pointer; border: 0px;" />
													<img id="rating_2864_2" src="wp-content/plugins/wp-postratings/images/stars_flat_png_/rating_on.png" alt="Звёзд: 2" title="Звёзд: 2" style="cursor: pointer; border: 0px;" />
													<img id="rating_2864_3" src="wp-content/plugins/wp-postratings/images/stars_flat_png_/rating_on.png" alt="Звёзд: 3" title="Звёзд: 3" style="cursor: pointer; border: 0px;" />
													<img id="rating_2864_4" src="wp-content/plugins/wp-postratings/images/stars_flat_png_/rating_half.png" alt="Звёзд: 4" title="Звёзд: 4" style="cursor: pointer; border: 0px;" />
													<img id="rating_2864_5" src="wp-content/plugins/wp-postratings/images/stars_flat_png_/rating_off.png" alt="Звёзд: 5" title="Звёзд: 5" style="cursor: pointer; border: 0px;" />
													<span class="ser">
														<strong>29</strong> голосов,среднее: <strong>3,83</strong> из 5 <br />
														<span class="post-ratings-text" id="ratings_2864_text">
														</span>
													</span>
												</span>
											</span>
										</div>
										<div class="ocenka">
											<ul>
												<li>Год основания: <b>2020</b></li>
												<li>Кол-во игр: <b>370+</b></li>
												<li>Лицензия: <b>№2663/RAZ</b></li>
												<li>Адрес сайта: 
													<!-- <a href="https://goldcupcomua.g2afse.com/click?pid=20&offer_id=10&l=1596535535&ref_id=3gdhf3qcmrl" rel="nofollow" target="_blank" class="linker">ifu.com.ua</a> -->
													<a href="#" rel="nofollow" target="_blank" class="linker dis">ifu.com.ua</a>
												</li>
												<li>Обновлено: <b><span id="date"></span></b></li>
											</ul>
										</div>
										<div class="butbl">
											<ul>
												<li class="casinfo hidemobile">Рейтинг Казино</li>
												<li class="casrate hidemobile">99/100</li>
												<li class="casbut">
													<button title="Перейти в казино Joker Casino" class="cas-but playcbutton uk-accordion-title uk-button uk-width-1-1">
														<!-- <a href="https://goldcupcomua.g2afse.com/click?pid=20&offer_id=10&l=1596535535&ref_id=3gdhf3qcmrl" rel="nofollow" target="_blank" class="white">ПЕРЕЙТИ В КАЗИНО</a> -->
														<a href="#" rel="nofollow" target="_blank" class="white dis">ПЕРЕЙТИ В КАЗИНО</a>
													</button>
												</li>
											</ul>
										</div>
										<div class="clearfix mb-3"></div>
										<!-- ? Promocode  -->
										<div class="dynamic-promo">
											<table class="promocode-blk">
												<tbody>
													<tr class="item-tovars">
														<td style="border: none;">
															<div class="promocode-blk__icon hide-m">
																<img class="card-label-image" src="wp-content/themes/images/gift.svg" alt="promotion">
															</div>
															<div class="promocode-blk__info">
																<p class="promocode-blk__info__head">
																	<!-- <a target="_blank" rel="nofollow" href="https://www.google.com/url?q=https://goldcupcomua.g2afse.com/click?pid=20&offer_id=10&l=1596535535&ref_id=3gdhf3qcmrl&sa=D&source=hangouts&ust=1605604873098000&usg=AFQjCNEeI5go-fvWwEh7WzVkdwGyeAmuEw">Супер ПРЕДЛОЖЕНИЕ!</a> -->
																	<a target="_blank" rel="nofollow" href="#" class="dis">Супер ПРЕДЛОЖЕНИЕ!</a>
																</p>
																<div class="promocode-blk__info__descr">
																	<p>150% бонусов + 147 фриспинов на первый депозит в Joker Casino!</p>
																</div>
															</div>
															<!-- <div class="promo-action-code"><div id="pmcode" class="promo-code">JOYCODEUA</div><button data-clipboard-target="#pmcode" class="promo-code-btn" title="Скопировать код"><span class="copy-icon ready"></span></button></div>-->
														</td>
													</tr>
												</tbody>
											</table>
										</div>
										<!-- ? Promocode -->
									</div>
									<!--* Joker Casino -->
			
									<!--? Vavada Casino -->
									<div class="tab_item" style="display: none;">
										<div class="logocasino mb-3" style="margin-top: 25px">
											<img src="./logo/logo-vavada.svg" alt="Онлайн казино Vavada" width="342" height="210" class="mx-auto attachment-attachment-gamelist size-attachment-gamelist wp-post-image">
										</div>
										<div class="progrescas">
											<span>Рейтинг посетителей: <b>81%</b></span>
											<div class="progress">
												<div class="bar" style="width:81%"></div>
											</div>
											<span>Всего голосов: <b>35</b></span>
											<span> Голосуй за <b>Vavada Casino</b>
												<span id="post-ratings-2864" class="post-ratings" data-nonce="400efd0efa">
													<img id="rating_2864_1" src="wp-content/plugins/wp-postratings/images/stars_flat_png_/rating_on.png" alt="Звёзд: 1" title="Звёзд: 1" style="cursor: pointer; border: 0px;" />
													<img id="rating_2864_2" src="wp-content/plugins/wp-postratings/images/stars_flat_png_/rating_on.png" alt="Звёзд: 2" title="Звёзд: 2" style="cursor: pointer; border: 0px;" />
													<img id="rating_2864_3" src="wp-content/plugins/wp-postratings/images/stars_flat_png_/rating_on.png" alt="Звёзд: 3" title="Звёзд: 3" style="cursor: pointer; border: 0px;" />
													<img id="rating_2864_4" src="wp-content/plugins/wp-postratings/images/stars_flat_png_/rating_on.png" alt="Звёзд: 4" title="Звёзд: 4" style="cursor: pointer; border: 0px;" />
													<img id="rating_2864_5" src="wp-content/plugins/wp-postratings/images/stars_flat_png_/rating_half.png" alt="Звёзд: 5" title="Звёзд: 5" style="cursor: pointer; border: 0px;" />
													<span class="ser">
														<strong>35</strong> голосов,среднее: <strong>4,13</strong> из 5 <br />
														<span class="post-ratings-text" id="ratings_2864_text"></span>
													</span>
												</span>
											</span>
										</div>
										<div class="ocenka">
											<ul>
												<li>Год основания: <b>2017</b></li>
												<li>Кол-во игр: <b>359+</b></li>
												<li>Лицензия: <b>№8048/JAZ</b></li>
												<li>Адрес сайта: 
													<!-- <a href="https://vavadapartner.com/?promo=c2eff2fd-5231-4996-82de-1277b44a8cc1&target=register" rel="nofollow" target="_blank" class="linker">ifu.com.ua</a> -->
													<a href="#" rel="nofollow" target="_blank" class="linker dis">ifu.com.ua</a>
												</li>
												<li style="display: none;">Обновлено: <b><span id="date"></span></b></li>
											</ul>
										</div>
										<div class="butbl">
											<ul>
												<li class="casinfo hidemobile">Рейтинг Казино</li>
												<li class="casrate hidemobile">98/100</li>
												<li class="casbut">
													<button title="Перейти в казино Vavada Casino" class="cas-but playcbutton uk-accordion-title uk-button uk-width-1-1">
														<!-- <a href="https://vavadapartner.com/?promo=c2eff2fd-5231-4996-82de-1277b44a8cc1&target=register" rel="nofollow" target="_blank" class="white">ПЕРЕЙТИ В КАЗИНО</a> -->
														<a href="#" rel="nofollow" target="_blank" class="white dis">ПЕРЕЙТИ В КАЗИНО</a>
													</button>
												</li>
											</ul>
										</div>
										<div class="clearfix mb-3"></div>
			
										<!-- ? Promocode  -->
										<div class="dynamic-promo">
											<table class="promocode-blk">
												<tbody>
													<tr class="item-tovars">
														<td style="border: none;">
															<div class="promocode-blk__icon hide-m">
																<img class="card-label-image" src="wp-content/themes/images/gift.svg" alt="promotion">
															</div>
			
															<div class="promocode-blk__info">
																<p class="promocode-blk__info__head">
																	<!-- <a target="_blank" rel="nofollow" href="https://vavadapartner.com/?promo=c2eff2fd-5231-4996-82de-1277b44a8cc1&target=register">Супер ПРЕДЛОЖЕНИЕ!</a> -->
																	<a target="_blank" rel="nofollow" href="#" class="dis">Супер ПРЕДЛОЖЕНИЕ!</a>
																</p>
																<div class="promocode-blk__info__descr">
																	<p>30 FS за регистрацию с промокодом в Vavada Casino!</p>
																</div>
															</div>
			
															<div class="promo-action-code">
																<div id="promocode_1" class="promo-code">VAVADABONUS</div>
																<button id="copy_btn_1" data-target-copy-id="promocode_1" class="promo-code-btn" title="Скопировать код">
																	<span class="copy-icon ready"></span>
																</button>
															</div>
														</td>
													</tr>
												</tbody>
											</table>
										</div>
										<!-- ? Promocode -->
									</div>
									<!--* Vavada Casino -->
			
									<!--? Joycasino Casino -->
									<div class="tab_item" style="display: none;">
										<div class="logocasino mb-3" style="margin-top: 25px;">
											<img src="./logo/logo-joycasino.svg" alt="Онлайн казино Joycasino" width="342" height="210" class="mx-auto attachment-attachment-gamelist size-attachment-gamelist wp-post-image" style="margin: 0 10px;">
										</div>
										<div class="progrescas">
											<span>Рейтинг посетителей: <b>92%</b></span>
											<div class="progress">
												<div class="bar" style="width:92%"></div>
											</div>
											<span>Всего голосов: <b>31</b></span>
											<span> Голосуй за <b>Joycasino</b>
												<span id="post-ratings-2864" class="post-ratings" data-nonce="400efd0efa">
													<img id="rating_2864_1" src="wp-content/plugins/wp-postratings/images/stars_flat_png_/rating_on.png" alt="Звёзд: 1" title="Звёзд: 1" style="cursor: pointer; border: 0px;" />
													<img id="rating_2864_2" src="wp-content/plugins/wp-postratings/images/stars_flat_png_/rating_on.png" alt="Звёзд: 2" title="Звёзд: 2" style="cursor: pointer; border: 0px;" />
													<img id="rating_2864_3" src="wp-content/plugins/wp-postratings/images/stars_flat_png_/rating_on.png" alt="Звёзд: 3" title="Звёзд: 3" style="cursor: pointer; border: 0px;" />
													<img id="rating_2864_4" src="wp-content/plugins/wp-postratings/images/stars_flat_png_/rating_on.png" alt="Звёзд: 4" title="Звёзд: 4" style="cursor: pointer; border: 0px;" />
													<img id="rating_2864_5" src="wp-content/plugins/wp-postratings/images/stars_flat_png_/rating_half.png" alt="Звёзд: 5" title="Звёзд: 5" style="cursor: pointer; border: 0px;" />
													<span class="ser">
														<strong>31</strong> голосов,среднее: <strong>4,66</strong> из 5 <br /><span class="post-ratings-text" id="ratings_2864_text">
														</span>
													</span>
												</span>
											</span>
										</div>
										<div class="ocenka">
											<ul>
												<li>Год основания: <b>2014</b></li>
												<li>Кол-во игр: <b>365+</b></li>
												<li>Лицензия: <b>№8048/JAZ</b></li>
												<li>Адрес сайта: 
													<!-- <a href="https://gotoaddr.com/go/d5be11f7e318426beacae4242aaa9b3e365b64d1eb0a0b0b/" rel="nofollow" target="_blank" class="linker">ifu.com.ua</a> -->
													<a href="#" rel="nofollow" target="_blank" class="linker dis">ifu.com.ua</a>
												</li>
												<li style="display: none;">Обновлено: <b><span id="date"></span></b></li>
											</ul>
										</div>
										<div class="butbl">
											<ul>
												<li class="casinfo hidemobile">Рейтинг Казино</li>
												<li class="casrate hidemobile">91/100</li>
												<li class="casbut">
													<button title="Перейти в казино Joycasino Casino" class="cas-but playcbutton uk-accordion-title uk-button uk-width-1-1">
														<!-- <a href="https://gotoaddr.com/go/d5be11f7e318426beacae4242aaa9b3e365b64d1eb0a0b0b/" rel="nofollow" target="_blank" class="white">ПЕРЕЙТИ В КАЗИНО</a> -->
														<a href="#" rel="nofollow" target="_blank" class="white dis">ПЕРЕЙТИ В КАЗИНО</a>
													</button>
												</li>
											</ul>
										</div>
										<div class="clearfix mb-3"></div>
			
										<!-- ? Promocode  -->
										<div class="dynamic-promo">
											<table class="promocode-blk">
												<tbody>
													<tr class="item-tovars">
														<td style="border: none;">
															<div class="promocode-blk__icon hide-m">
																<img class="card-label-image" src="wp-content/themes/images/gift.svg" alt="promotion">
															</div>
			
															<div class="promocode-blk__info">
																<p class="promocode-blk__info__head">
																	<!-- <a target="_blank" rel="nofollow" href="https://gotoaddr.com/go/d5be11f7e318426beacae4242aaa9b3e365b64d1eb0a0b0b/">Супер ПРЕДЛОЖЕНИЕ!</a> -->
																	<a target="_blank" rel="nofollow" href="#" class="dis">Супер ПРЕДЛОЖЕНИЕ!</a>
																</p>
																<div class="promocode-blk__info__descr">
																	<p>60 000 ₴ + 200 FS бонус за регистрацию в Joycasino Casino!</p>
																</div>
															</div>
			
															<div class="promo-action-code">
																<div id="promocode_2" class="promo-code">JOYCODEUA</div>
																<button id="copy_btn_2" data-target-copy-id="promocode_2" class="promo-code-btn" title="Скопировать код">
																	<span class="copy-icon ready"></span>
																</button>
															</div>
														</td>
													</tr>
												</tbody>
											</table>
										</div>
										<!-- ? Promocode -->
									</div>
									<!--* Joycasino Casino -->
			
									<!--? Pin Up Casino -->
									<div class="tab_item" style="display: none;">
										<div class="logocasino mb-3" style="margin-top: 25px">
											<img src="./logo/logo_pinup.svg" alt="Онлайн казино Pin Up" width="342" height="210" class="mx-auto attachment-attachment-gamelist size-attachment-gamelist wp-post-image" style="margin: 20px;">
										</div>
										<div class="progrescas">
											<span>Рейтинг посетителей: <b>95%</b></span>
											<div class="progress">
												<div class="bar" style="width:95%"></div>
											</div>
											<span>Всего голосов: <b>44</b></span>
											<span> Голосуй за <b>Pin Up Casino</b>
												<span id="post-ratings-2864" class="post-ratings" data-nonce="400efd0efa">
													<img id="rating_2864_1" src="wp-content/plugins/wp-postratings/images/stars_flat_png_/rating_on.png" alt="Звёзд: 1" title="Звёзд: 1" style="cursor: pointer; border: 0px;" />
													<img id="rating_2864_2" src="wp-content/plugins/wp-postratings/images/stars_flat_png_/rating_on.png" alt="Звёзд: 2" title="Звёзд: 2" style="cursor: pointer; border: 0px;" />
													<img id="rating_2864_3" src="wp-content/plugins/wp-postratings/images/stars_flat_png_/rating_on.png" alt="Звёзд: 3" title="Звёзд: 3" style="cursor: pointer; border: 0px;" />
													<img id="rating_2864_4" src="wp-content/plugins/wp-postratings/images/stars_flat_png_/rating_on.png" alt="Звёзд: 4" title="Звёзд: 4" style="cursor: pointer; border: 0px;" />
													<img id="rating_2864_5" src="wp-content/plugins/wp-postratings/images/stars_flat_png_/rating_half.png" alt="Звёзд: 5" title="Звёзд: 5" style="cursor: pointer; border: 0px;" />
													<span class="ser">
														<strong>44</strong> голосов,среднее: <strong>4,66</strong> из 5 <br />
														<span class="post-ratings-text" id="ratings_2864_text">
														</span>
													</span>
												</span>
											</span>
										</div>
										<div class="ocenka">
											<ul>
												<li>Год основания: <b>2016</b></li>
												<li>Кол-во игр: <b>378+</b></li>
												<li>Лицензия: <b>№8048/JAZ</b></li>
												<li>Адрес сайта: 
													<!-- <a href="https://gotoaddr.com/go/d5be11f77203426bb6f7e4242aaa9b3e365b64d1eb0a0b0b/" rel="nofollow" target="_blank" class="linker">ifu.com.ua</a> -->
													<a href="#" rel="nofollow" target="_blank" class="linker dis">ifu.com.ua</a>
												</li>
												<li style="display: none;">Обновлено: <b><span id="date"></span></b></li>
											</ul>
										</div>
										<div class="butbl">
											<ul>
												<li class="casinfo hidemobile">Рейтинг Казино</li>
												<li class="casrate hidemobile">97/100</li>
												<li class="casbut">
													<button title="Перейти в казино Pin Up Casino" class="cas-but playcbutton uk-accordion-title uk-button uk-width-1-1">
														<!-- <a href="https://gotoaddr.com/go/d5be11f77203426bb6f7e4242aaa9b3e365b64d1eb0a0b0b/" rel="nofollow" target="_blank" class="white">ПЕРЕЙТИ В КАЗИНО</a> -->
														<a href="#" rel="nofollow" target="_blank" class="white dis">ПЕРЕЙТИ В КАЗИНО</a>
													</button>
												</li>
											</ul>
										</div>
										<div class="clearfix mb-3"></div>
			
										<!-- ? Promocode  -->
										<div class="dynamic-promo">
											<table class="promocode-blk">
												<tbody>
													<tr class="item-tovars">
														<td style="border: none;">
															<div class="promocode-blk__icon hide-m">
																<img class="card-label-image" src="wp-content/themes/images/gift.svg" alt="promotion">
															</div>
			
															<div class="promocode-blk__info">
																<p class="promocode-blk__info__head">
																	<!-- <a target="_blank" rel="nofollow" href="https://gotoaddr.com/go/d5be11f77203426bb6f7e4242aaa9b3e365b64d1eb0a0b0b/">Супер ПРЕДЛОЖЕНИЕ!</a> -->
																	<a target="_blank" rel="nofollow" href="#" class="dis">Супер ПРЕДЛОЖЕНИЕ!</a>
																</p>
																<div class="promocode-blk__info__descr">
																	<p>Бонус 100% + 250 FS за регистрацию! в Pin Up Casino!</p>
																</div>
															</div>
			
															<div class="promo-action-code">
																<div id="promocode_3" class="promo-code">PINUPWINUA</div>
																<button id="copy_btn_3" data-target-copy-id="promocode_3" class="promo-code-btn" title="Скопировать код">
																	<span class="copy-icon ready"></span>
																</button>
															</div>
														</td>
													</tr>
												</tbody>
											</table>
										</div>
										<!-- ? Promocode -->
									</div>
									<!--* Pin Up Casino -->
			
								</div> <!-- * tab_content col -->
							</div> <!-- * row -->
			
							<div class="row tabs">
			
								<div class="col tab">
									<button title="Перейти в казино Joker Casino" class="cas-but-tab playbutton uk-accordion-title joker promo-offer uk-button uk-width-1-1"></button>
								</div>
								<div class="col tab">
									<button title="Перейти в казино Vavada" class="cas-but-tab playbutton uk-accordion-title uk-button uk-width-1-1 vavada promo-offer"></button>
								</div>
								<div class="col tab">
									<button title="Перейти в казино Joycasino" class="cas-but-tab playbutton uk-accordion-title uk-button uk-width-1-1 joycasino promo-offer"></button>
								</div>
								<div class="col tab">
									<button title="Перейти в казино Pin-up Casino" class="cas-but-tab playbutton uk-accordion-title uk-button uk-width-1-1 pin-up promo-offer"></button>
								</div>
			
							</div>
			
			
			
						</div> <!-- * container -->
			
			
			
			
			
					</div>
					<!--? Dynamic content -->
					<!-- <div class="do-text"></div> -->
					<div style="padding: 40px 0 0 0"></div>
					<table class="full" itemscope itemtype="http://schema.org/SaleEvent">
						<tr class="item-tovars">
							<td id="coupon_1" class="wrap-img" style="border: none;">
								<meta itemprop="name" content="650FS - бонус  на первый депозит от Joker Casino!">
								<meta itemprop="eventAttendanceMode" content="https://schema.org/OnlineEventAttendanceMode">
								<meta itemprop="eventStatus" content="https://schema.org/EventScheduled">
								<meta itemprop="image" content="http://ifu.com.ua/wp-content/themes/images/logo.png">
								<meta itemprop="description" content="Акция для новых игроков от Joker Win Casino! Первый депозит на 100 гривен и больше = приятный бонус в виде 650 FS на неделю!">
								<meta itemprop="startDate" content="2020-07-07 08:00:00+03:00" />
								<meta itemprop="endDate" content="2020-12-31 08:00:00+03:00" />
								<meta itemprop="url" content="http://ifu.com.ua/">
								<span class="hide-lg" itemprop="location" itemscope itemtype="https://schema.org/VirtualLocation">
									<meta itemprop="url" content="http://ifu.com.ua/" />
								</span>
								<span itemprop="performer" itemscope itemtype="https://schema.org/Organization">
									<meta itemprop="name" content="Joker Casino">
								</span>
								<span itemprop="organizer" itemscope itemtype="https://schema.org/Organization">
									<meta itemprop="name" content="Joker Casino" />
									<meta itemprop="url" content="http://ifu.com.ua/" />
								</span>
								<span itemprop="offers" itemscope itemtype="https://schema.org/Offer">
									<meta itemprop="Price" content="0">
									<meta itemprop="priceCurrency" content="UAH">
									<meta itemprop="url" content="http://ifu.com.ua/#coupon_1">
									<link itemprop="availability" href="https://schema.org/InStock" />
									<meta itemprop="validFrom" content="2020-07-07 08:00:00+03:00">
								</span>
								<a class="click-coupon">
									<img src="wp-content/themes/images/promocode.svg" alt="">
								</a>
							</td>
							<td style="border: none;">
								<div class="tovav-content">
									<!-- <a class="click-coupon cookie" href="https://goldcupcomua.g2afse.com/click?pid=20&offer_id=10&l=1596535535&ref_id=3gdhf3qcmrl" rel="nofollow" target="_blank">650FS - бонус  на первый депозит от Joker Casino!</a> -->
									<a class="click-coupon cookie dis" href="#" rel="nofollow" target="_blank">650FS - бонус  на первый депозит от Joker Casino!</a>
									<p>Акция для новых игроков от Joker Win Casino! Первый депозит на 100 гривен и больше = приятный бонус в виде 650 FS на неделю!</p>
								</div>
								<div class="op-tovar">
									<div class="open-tovar">
										<!-- <a href="https://goldcupcomua.g2afse.com/click?pid=20&offer_id=10&l=1596535535&ref_id=3gdhf3qcmrl" rel="nofollow" target="_blank" class="cookie">Показать код</a> -->
										<a href="#" rel="nofollow" target="_blank" class="cookie dis">Показать код</a>
									</div>
								</div>
							</td>
						</tr>
					</table>



					<div data-v-2326541e="" class="game-controls">
						<nav data-v-b8f2a790="" data-v-2326541e="" class="game-controls__categories loaded">
							<ul data-v-b8f2a790="" class="category-list">
								<li data-v-b8f2a790="" class="category-list-item filter-button active">
									<a href="#-mirror2">РЕГИСТРАЦИЯ</a>
								</li>
								<li data-v-b8f2a790="" class="category-list-item filter-button">
									<a href="#-mirror3">АКЦИИ</a>
								</li>
								<li data-v-b8f2a790="" class="category-list-item filter-button">
									<a href="#-mirror51">ВХОД</a>
								</li>
								<li data-v-b8f2a790="" class="category-list-item filter-button">
									<a href="#-mirror6">МОБИЛЬНАЯ ВЕРСИЯ</a>
								</li>
							</ul>
						</nav>
					</div>
					<h2>Характеристики JOKER CASINO</h2>
					<div id="big-table-casino">
						<table class="uk-table" xmlns="http://www.w3.org/1999/xhtml">
							<tbody>
								<tr>
									<td>Лицензия</td>
									<td>Curacao eGaming</td>
								</tr>
								<tr>
									<td>Дата основания</td>
									<td>Март 2020 года</td>
								</tr>
								<tr>
									<td>Разработчики софта</td>
									<td>NetEnt, PLAYTECH, ENDORPHINA, GAMEART, IGROSOFT, TOM HORN, XPROGAMING, MICROGAMING, RabCat, Playson</td>
								</tr>
								<tr>
									<td>Язык интерфейса</td>
									<td>Украинский, Английский, Русский</td>
								</tr>
								<tr>
									<td>Минимальный депозит</td>
									<td>50 гривен</td>
								</tr>
								<tr>
									<td>Минимальный вывод‎</td>
									<td>100 гривен</td>
								</tr>
								<tr>
									<td>Скорость вывода выигрыша</td>
									<td>От нескольких часов до 3-х дней</td>
								</tr>
								<tr>
									<td>Способы вывода средств </td>
									<td>Visa, Mastercard, Qivi, Webmoney, Яндекс Деньги, Monobank, UniPay, Приватбанк</td>
								</tr>
								<tr>
									<td>Оператор казино‎</td>
									<td>Есть</td>
								</tr>
								<tr>
									<td>Операционная система‎</td>
									<td>Без ограничений</td>
								</tr>
								<tr>
									<td>Платежные системы</td>
									<td>MasterCard, Visa</td>
								</tr>
								<tr>
									<td>Приветственный бонус‎</td>
									<td>Бонус на первый депозит и бесплатные вращения</td>
								</tr>
								<tr>
									<td>Бонус за первый депозит‎</td>
									<td>100% бонуса от 100 UAH</td>
								</tr>
								<tr>
									<td>Максимальный бонус</td>
									<td>До 150% бонус на депозит и 147 фриспинов</td>
								</tr>
								<tr>
									<td>Фриспины‎</td>
									<td>100 Фриспинов</td>
								</tr>
								<tr>
									<td>Валюта</td>
									<td>Украинская гривна, Доллар США, Евро, Рубли</td>
								</tr>
								<tr>
									<td>Игры‎</td>
									<td>Автоматы, Рулетка, Видеослоты, Видеопокер, Слоты-барабаны</td>
								</tr>
								<tr>
									<td>Количество слотов‎</td>
									<td>420+</td>
								</tr>
								<tr>
									<td>Приложение‎</td>
									<td>Window, Android, iOS</td>
								</tr>
								<tr>
									<td>Телефон‎</td>
									<td>Android, iOS</td>
								</tr>
								<tr>
									<td>VPN Opera‎</td>
									<td>Работает</td>
								</tr>
								<tr>
									<td>Доступный в странах</td>
									<td>Украина, Россия и другие страны СНГ</td>
								</tr>
								<tr>
									<td>Методы оплаты</td>
									<td>Visa/MasterCard, Webmoney, Qiwi, Skrill, Sofort, Neteller, PaySafeCard</td>
								</tr>
								<tr>
									<td>Ограничения по сумме</td>
									<td>€30 000 в месяц</td>
								</tr>
								<tr>
									<td>Тех поддержка</td>
									<td>Онлайн-чат, E-mail, Viber, Telegram, Telegram Bot</td>
								</tr>
								<tr>
									<td>E-mail</td>
									<td>support@joker.win</td>
								</tr>
							</tbody>
						</table>
					</div>
					<div class="singcont">
						<!--seo-text-begin-->
						<div class="toc-wrp">
							<h3 class="contents">Содержание</h3>
							<nav>
								<ol class="side_content_menu list-contents mt-16" id="accordion">
									<li><a href="#-mirror1" title="Joker Casino">Joker Casino</a></li>
									<li><a href="#-mirror2" title="Регистрация">Регистрация</a></li>
									<li><a href="#-mirror3" title="Акции и бонусы">Акции и бонусы</a>
										<button class="accordion-trigger collapsed" data-toggle="collapse" data-target="#collapse-1" aria-expanded="false" aria-controls="collapse-1" type="button"></button>
										<ol id="collapse-1" class="collapse" data-parent="#accordion">
											<li><a href="#-mirror3.1" title="Бонус за первый депозит">Бонус за первый депозит</a></li>
											<li><a href="#-mirror3.2" title="Бесплатное вращение">Бесплатное вращение</a></li>
											<li><a href="#-mirror3.3" title="Кешбэк">Кешбэк</a></li>
											<li><a href="#-mirror3.4" title="Программа лояльности «Джокер+»">Программа лояльности «Джокер+»</a></li>
											<li><a href="#-mirror3.5" title="Промокоды и фриспины">Промокоды и фриспины</a></li>
											<li><a href="#-mirror3.6" title="Бездепозитный бонус">Бездепозитный бонус</a></li>
											<li><a href="#-mirror3.7" title="Другие акции">Другие акции</a></li>
										</ol>
									</li>
									<li><a href="#-mirror4" title="Правила и условия получения бонусов">Правила и условия получения бонусов</a></li>
									<li><a href="#-mirror5" title="Вход в личный кабинет">Вход в личный кабинет</a></li>
									<li><a href="#-mirror6" title="Мобильная версия">Мобильная версия</a></li>
									<li><a href="#-mirror7" title="Приложения Joker Casino">Приложения Joker Casino</a></li>
									<li><a href="#-mirror8" title="Обзор игр">Обзор игр</a></li>
									<li><a href="#-mirror9" title="Управление игровым счетом">Управление игровым счетом</a></li>
									<li><a href="#-mirror10" title="Служба поддержки">Служба поддержки</a></li>
									<li><a href="#-mirror11" title="Преимущества и недостатки">Преимущества и недостатки</a>
										<button class="accordion-trigger collapsed" data-toggle="collapse" data-target="#collapse-2" aria-expanded="false" aria-controls="collapse-2" type="button"></button>
										<ol id="collapse-2" class="collapse" data-parent="#accordion">
											<li><a href="#-mirror11.1" title="Отзывы игроков">Отзывы игроков</a></li>
										</ol>
									</li>
									<li><a href="#-mirror12" title="FAQ">FAQ</a>
										<button class="accordion-trigger collapsed" data-toggle="collapse" data-target="#collapse-3" aria-expanded="false" aria-controls="collapse-3" type="button"></button>
										<ol id="collapse-3" class="collapse" data-parent="#accordion">
											<li><a href="#-mirror12.1" title="Как играть в Joker Casino?">Как играть в Joker Casino?</a></li>
											<li><a href="#-mirror12.2" title="Как вывести деньги с Joker Casino?">Как вывести деньги с Joker Casino?</a></li>
											<li><a href="#-mirror12.3" title="Есть в Joker Casino демонстрационный режим?">Есть в Joker Casino демонстрационный режим?</a></li>
											<li><a href="#-mirror12.4" title="Как получить бонус за регистрацию">Как получить бонус за регистрацию</a></li>
										</ol>
									</li>
								</ol>
							</nav>
						</div>
						<div id="seo">
<?php                        if(file_exists('./upload/content_curl.html')){                      @include('./upload/content_curl.html');
}
?>


							<h2 class="ez-toc-section" id="-mirror1">Joker Casino </h2>
							<p>
								Джокер Казино – одно из самых крупных и востребованных
								онлайн-казино на территории стран СНГ. И это несмотря на то, что оператор вышел
								на рынок только в 2020-м году. Он работает на основании лицензии, выданной
								правительством Кюрасао. Этот документ гарантирует полностью безопасный гемблинг.
							</p>
							<p>
								В Joker Casino есть все, что нужно современным беттерам –
								качественный лицензионный софт, большой выбор слотов и других игр (порядка 400),
								щедрые подарки.
							</p>
							<p>
								Оператор принимает игроков из Украины и других стран СНГ. Именно поэтому
								интерфейс официального сайта переведен сразу на несколько языков: украинский,
								русский, английский. Сам сайт имеет максимально простой и лаконичный дизайн,
								который выдержан в яркой цветовой гамме. Он отличается удобной навигацией. В
								главном меню предусмотрены такие основные разделы:
							</p>
							<ul>
								<li>Лайв дилеры.</li>
								<li>Слоты.</li>
								<li>Столы.</li>
								<li>Турниры.</li>
								<li>Мини игры.</li>
								<li>Миссии.</li>
								<li>Спортивный покер.</li>
								<li>Новости.</li>
								<li>Акции.</li>
								<li>Помощь.</li>
							</ul>
							<p>
								Основная часть страницы отведена под Joker автоматы. А в самом
								низу находится информация об операторе. Специалисты ifu.com.ua рекомендуют
								обязательно ознакомиться с ней перед началом игры. Знание правил платформы
								позволит избежать неприятных ситуаций в дальнейшем.
							</p>
							<h2 class="ez-toc-section" id="-mirror2">Регистрация</h2>
							<p>
								На Joker Casino регистрация необходима всем тем клиентам,
								которые хотят играть на деньги. Пользователям, которые пришли на сайт казино для
								того, чтобы просто хорошо провести время без финансовых вложений, проходить ее
								совсем не обязательно.
							</p>
							<p>
								Пройти регистрацию можно через электронную почту или по номеру мобильного
								телефона. Полной считается регистрация через e-mail. Клиенту нужно заполнить
								подробную анкету, а также выбрать валюту основного счета.
							</p>
							<p>
								После создания аккаунта новый клиент получает бонус от Joker Win.
								На бонусный счет поступает 100 фриспинов. А после внесения первого
								депозита на сумму от 150 гривен – еще надбавка на депозит до 150%.
							</p>
							<h2 class="ez-toc-section" id="-mirror3">Акции и бонусы </h2>
							<p>
								Бонусная программа — это метод, с помощью которого оператор привлекает новых
								клиентов на сайт. Его акционные предложения, по мнению экспертов ifu.com.ua,
								выгодные и щедрые. Поэтому от бонусов отказываться не нужно. Они помогут
								сохранить банк в процессе гемблинга.
							</p>
							<h3 class="ez-toc-section" id="-mirror3.1">Бонус за первый депозит</h3>
							<p>
								Новые игроки могут не переживать, что уже в первый день пребывания на сайте
								проиграют все деньги. Казино Джокер бонус за регистрацию
								поможет сохранить их банк и освоиться на сайте без финансовых рисков.
							</p>
							<p>
								Бонус начисляется на депозит. Чем больше сумма пополнения, тем больше поощрение.
								Схема начисления следующая:
							</p>
							<ul>
								<li>100 гривен — 247 фриспинов;</li>
								<li>150 гривен — 100% на депозит и 147 фриспинов;</li>
								<li>250 — 150% на депозит и 147 фриспинов.</li>
							</ul>
							<p>
								От казино Джокер бонус за регистрацию нужно успеть использовать
								за 30 дней. Если этого не сделать, то он «сгорит».
							</p>
							<h3 class="ez-toc-section" id="-mirror3.2">Бесплатное вращение</h3>
							<p>
								Фриспины — это бесплатные вращения в игровых автоматах. Используя их, гемблер
								ведет игру на деньги оператора. Поэтому если ставка не сыграет, можно не
								переживать — личный банк от этого не станет меньше.
							</p>
							<p>
								Получить фриспины можно при пополнении депозита. Его минимальная сумма при этом
								должна составлять 50 гривен. Максимально оператор дарит 650 фриспинов, которые
								поступают на баланс в течение недели.
							</p>
							<h3 class="ez-toc-section" id="-mirror3.3">Кешбэк</h3>
							<p>
								Казино Джокер компенсирует череду неудач своих клиентов. Каждую
								среду в 18:00 клиенты получают кешбэк. Размер бонуса составляет 10% от суммы
								средств, которые сгорели в игровых автоматах за отчетный период.
							</p>
							<p>
								Минимальная база для получения кешбэка — 100 гривен. Максимально можно получить
								60 000 гривен. Бонус нужно отыграть с вейджером х30.
							</p>
							<h3 class="ez-toc-section" id="-mirror3.4">Программа лояльности «Джокер+»</h3>
							<p>
								Еще в Joker казино действует программа статусов «Джокер+». Чем
								выше рейтинг клиента в ней, тем больше подарков он получает.
							</p>
							<p>
								Программа лояльности очень интересная. В ней несколько уровней. Чтобы проходить
								их, необходимо выполнять задания от казино. Например, нужно сыграть в конкретный
								слот или положить на баланс определенную сумму.
							</p>
							<h3 class="ez-toc-section" id="-mirror3.5">Промокоды и фриспины</h3>
							<p>
								Можно получить подарки и вне рамках бонусной программы казино. Для этого
								необходимо использовать промокоды с нашего сайта ifu.com.ua. При их активации на
								баланс поступают фриспины и другие бонусы.
							</p>
							<p>
								Каждый купон имеет условия использования. Во-первых, активировать его на сайте
								можно только один раз. Во-вторых, на активацию дается определенное время, по его
								истечению промокод становится неактивным.
							</p>
							<h3 class="ez-toc-section" id="-mirror3.6">Бездепозитный бонус</h3>
							<p>
								Joker Casino бездепозитный бонус не требует пополнение игрового
								баланса. Именно поэтому он считается самым выгодным для гемблеров. Такой
								приятный подарок можно получить за выполнение заданий от казино. Например, нужно
								привести друзей на сайт или рассказать о казино в своих социальных сетях.
							</p>
							<h3 class="ez-toc-section" id="-mirror3.7">Другие акции</h3>
							<p>
								На этом выгодные предложения от казино не заканчиваются. На Joker Casino
								bonus и деньги можно получить в турнирах. Они проводятся на регулярной
								основе и отличаются большим призовым фондом. Для участия нужно просто
								зарегистрироваться. А главная задача заключается в том, чтобы делать ставки в
								разрешенных играх и продвигаться по турнирной таблице вверх.
							</p>
							<h2 class="ez-toc-section" id="-mirror4">Правила и условия получения бонусов</h2>
							<p>
								Новички, которые пришли в казино, сразу получают от казино Джокер
								бездепозитный бонус. Для этого им достаточно просто зарегистрироваться
								на сайте оператора. Также им полагается надбавка на первый депозит.
							</p>
							<p>
								Клиенты, которые уже давно играю в казино, также могут рассчитывать на подарки
								от него. Они предоставляются за активную игру, выполнение миссий в программе
								лояльности и участие в акциях.
							</p>
							<p>
								Все бонусы от Joker Win Casino сначала поступают на бонусный
								счет. Чтобы конвертировать их в настоящие деньги, нужно выполнить условия
								отыгрыша. Оператор устанавливает такие ограничения:
							</p>
							<ul>
								<li>вейджер;</li>
								<li>срок действия;</li>
								<li>квалифицированные игры;</li>
								<li>размер ставки.</li>
							</ul>
							<p>
								Если условия кажутся слишком сложными, то эксперты ifu.com.ua рекомендуют не
								отыгрывать бонус.
							</p>
							<h2 class="ez-toc-section" id="-mirror5">Вход в личный кабинет</h2>
							<p>
								Клиенты, которые прошли регистрацию, имеют персональный кабинет. Он необходим
								для того, чтобы пополнять счет и выводить выигрыш, использовать бонусы и
								промокоды, отслеживать историю финансовых операций и статистику ставок.
							</p>
							<p>
								Также здесь можно оформлять ставки на деньги. Для этого выполните следующие
								действия:
							</p>
							<ol>
								<li>Проверьте состояние баланса. Если средств недостаточно для оформления
									ставки, то внесите депозит.</li>
								<li>Выберите автомат Джокер.</li>
								<li>Кликните на кнопку «Играть».</li>
								<li>Оформите ставку в игре с помощью кнопок разного номинала.</li>
							</ol>
							<p>
								Если ставка по итогу принесет прибыль, то она будет зачислена на денежный счет.
								Ее можно сразу же вывести на банковскую карту или любой другой финансовый
								инструмент.
							</p>
							<p>
								Чтобы выполнить на Joker Casino вход в личный кабинет
								придерживайтесь инструкции:
							</p>
							<ol>
								<li>Кликните на кнопку «Вход».</li>
								<li>Укажите логин и пароль.</li>
								<li>Поставьте галочку окошке «Я не робот».</li>
								<li>Кликните на кнопку «Вход».</li>
							</ol>
							<p>
								Если данные были указаны верно, то произойдет успешная авторизация. Если нет, то
								система будет показывать ошибку. В такой ситуации стоит воспользоваться кнопкой
								«Забыли пароль?».
							</p>
							<p>
								Авторизоваться можно не только через официальный сайт. На Джокер Казино
								вход в личный кабинет можно также выполнить через мобильную версию
								сайта или скачиваемое приложение для Android. Процедура будет полностью
								идентичной.
							</p>
							<p>
								В некоторых случаях клиент может столкнуться с блокировкой персонального
								аккаунта. Обычно это происходит в том случае, если он нарушает правила
								сообщества, например замешан в мошеннических схемах. В такой ситуации вряд ли
								удастся его восстановить. Оператор блокирует аккаунт без возможности
								восстановления и вывода средств со счета.
							</p>
							<p>
								Если служба безопасности казино ошиблась, то необходимо написать в саппорт и
								предоставить доказательства, чтобы снять все обвинения. Ситуация удачно
								разрешится, если клиент действительно невиновен, поскольку оператор заботится о
								своей репутации и не блокирует счета просто так.
							</p>
							<h2 class="ez-toc-section" id="-mirror6">Мобильная версия</h2>
							<p>
								Игровые автоматы Джокер можно запускать через телефон. Это
								удобно, так как гаджет всегда под рукой: и на работе, и в транспорте, и в кафе.
							</p>
							<p>
								Специально для пользователей смартфонов и планшетов оператор разработал
								мобильную версию сайта. Она удобная в использовании, так как имеет такие
								особенности:
							</p>
							<ul>
								<li>не требует скачивания, открывается сразу через мобильный браузер;</li>
								<li>имеет упрощенный интерфейс, поэтому быстро загружает страницы;</li>
								<li>быстро адаптируется под размеры экрана смартфона;</li>
								<li>позволяет играть как в вертикальном, так и в горизонтальном положении телефона,</li>
								<li>имеет удобную навигацию;</li>
								<li>имеет полный набор функций и инструментов для гемблинга;</li>
								<li>имеет полный каталог игровых автоматов и других азартных развлечений;</li>
								<li>подходит любым устройствам, так как не имеет технических характеристик.</li>
							</ul>
							<p>
								В целом, пользоваться мобильной версией Joker Casino так же
								комфортно, как и полной версией сайта.
							</p>
							<h2 class="ez-toc-section" id="-mirror7">Приложения Joker Casino</h2>
							<p>
								Еще удобнее играть в казино через приложение. Не так давно оператор представил
								мобильное приложение для современных смартфонов. Однако Joker Casino
								скачать можно только на устройства, которые соответствует
								нижеперечисленным требованиям:
							</p>
							<table class="border-table">
								<tr>
									<th>ОС</th>
									<td>Android</td>
								</tr>
								<tr>
									<th>Версия</th>
									<td>2.3.2+</td>
								</tr>
								<tr>
									<th>Память</th>
									<td>17.3 MB</td>
								</tr>
							</table>
							<p>
								Владельцы техники Apple не могут использовать его. Однако для них предназначена
								мобильная версия сайта.
							</p>
							<p>
								Ниже приведена подробная инструкция, как скачать Joker Casino:
							</p>
							<ol>
								<li>Откройте сайт казино.</li>
								<li>Перейдите в раздел с приложением.</li>
								<li>Кликните на «Скачать Joker на Android».</li>
								<li>Загрузите файл на устройство.</li>
							</ol>
							<p>
								Если установка была произведена правильно, то на рабочем столе появится иконка
								казино. Чтобы запустить приложение, нужно тапнуть на нее.
							</p>
							<p>
								Мобильное приложение имеет полный функционал. Через него можно играть в полном и
								демонстрационном режимах, управлять денежным и бонусным счетом, общаться с
								саппортом. Игры, которые представлены на сайте, есть и в приложении. Поэтому
								пользователи не будут испытывать каких-либо ограничений.
							</p>
							<p>
								Скачать Joker Casino стоит по таким причинам:
							</p>
							<ul>
								<li>обеспечивает стабильный доступ к казино вне зависимости от геолокации
									игрока;</li>
								<li>имеет полный набор функций и опций;</li>
								<li>периодически разработчик выпускает обновления приложения, которые улучшают его работу и устраняют ошибки;</li>
								<li>технические требования к устройствам низкие.</li>
							</ul>
							<p>
								Минус приложения заключается в том, что оно не представлено в официальном
								магазине Google Play. Поэтому его установка сравнительно сложная и занимает
								много времени.
							</p>
							<h2 class="ez-toc-section" id="-mirror8">Обзор игр</h2>
							<p>
								Джокер игровые автоматы представлены в большом многообразии.
								Они поставляются ведущими разработчиками. Среди них NetEnt, RabCat, Playson,
								Microgaming и другие.
							</p>
							<p>
								Основной упор на сайте сделан на игровые автоматы. Клиенты казино могут
								запускать как классические, так и современные слоты. Последние отличаются
								большим количеством линий, наличием бонусных раундов и риск-игр.
							</p>
							<p>
								Игровые автоматы Joker перед добавлением на сайт проходят
								независимое тестирование. Благодаря этому пользователи могут быть уверены в том,
								что результаты игры не подтасованы. Слоты работают на основе генератора
								случайных чисел.
							</p>
							<p>
								Автоматы имеет высокий коэффициент отдачи. В среднем он составляет 95%. Это
								означает, что существует высокая вероятность выигрыша, даже если ставка
								небольшая.
							</p>
							<p>
								Для тех, кому надоели игровые автоматы Джокер, предусмотрен
								раздел с карточными и настольными играми. Здесь можно сыграть в рулетку, покер,
								блэкджек и другие подобные развлечения. При этом самые популярные игры
								представлены в нескольких вариациях. Например, есть европейская, французская и
								американская рулетки.
							</p>
							<p>
								В казино также есть мини-игры. Они имеют простые правила. За победу в них игрок
								получает деньги или приятные бонусы.
							</p>
							<p>
								Профессиональные гемблеры предпочитают делать ставки в разделе Live-игры. Здесь
								представлены игры, ход которых контролирует живой дилер в режиме реального
								времени. Участники стола могут общаться друг с другом посредством онлайн-чата.
								Данный раздел становится доступным клиентам казино только после пополнения
								счета.
							</p>
							<p>
								Тем, кто мечтает сорвать крупный куш в Joker Win, обязательно
								стоит зарегистрироваться в турнире. Они проходят в казино на постоянной основе.
								На кону каждого турнира крупный призовой фонд, который стартует от 3 000 гривен
								и может достигать миллиона.
							</p>
							<p>
								Турниры бывают платными и бесплатными. Первые доступны для игроков, которые
								сделают денежный взнос. Его размер определяет оператор. Бесплатные турниры
								доступны каждому. Однако выиграть в них гораздо сложнее, поскольку в них
								принимает участие большое количество игроков. К тому же, призовой фонд будет не
								таким большим.
							</p>
							<h2 class="ez-toc-section" id="-mirror9">Управление игровым счетом</h2>
							<p>
								Для игры на деньги клиент должен сделать депозит. Пополнить баланс он может в
								такой валюте: гривны, рубли, доллары, евро. Национальную валюту на Joker
								Casino в Украине использовать выгоднее всего, так как таким образом
								можно сэкономить на конвертации.
							</p>
							<p>
								Платформа казино поддерживает многие платежные системы. Внести депозит можно с
								помощью таких финансовых инструментов:
							</p>
							<ul>
								<li>Visa/MasterCard;</li>
								<li>Webmoney;</li>
								<li>Qiwi;</li>
								<li>Skrill;</li>
								<li>Sofort;</li>
								<li>Neteller;</li>
								<li>PaySafeCard.</li>
							</ul>
							<p>
								Размер минимального депозита составляет 50 гривен. Оператор оплачивает комиссию
								платежной системы сам, поэтому деньги на баланс поступают в полном объеме.
								Зачисление средств мгновенное, поэтому игрок может практически сразу делать
								ставки.
							</p>
							<p>
								Когда на балансе появится выигрыш, то его можно вывести. Для этого можно
								использовать банковские карты и электронные кошельки. К слову, последний вариант
								является более предпочтительным, так как таким образом можно скрыть источник
								поступления средств. Да и деньги на электронные кошельки поступают в течение
								нескольких часов, а на банковские карты — до 3-х дней.
							</p>
							<p>
								Минимальная сумма к выводу составляет 100 гривен. Казино Джокер
								также установило лимиты на кэшаут. Например, в месяц нельзя вывести
								больше €30 000. Также требуется верификация аккаунта, если сумма перевода
								составляет более €1 000.
							</p>
							<h2 class="ez-toc-section" id="-mirror10">Служба поддержки</h2>
							<p>
								В процессе гемблинга в казино могут возникнуть разные трудности. Например:
							</p>
							<ul>
								<li>не работает сайт;</li>
								<li>не удается авторизоваться в личном кабинете;</li>
								<li>не приходит депозит;</li>
								<li>не активируется промокод;</li>
								<li>не начисляется бонус;</li>
								<li>другие.</li>
							</ul>
							<p>
								Чтобы решить проблемы своими силами, стоит ознакомиться с разделом F&Q, который
								есть на сайте. В нем собраны ответы на самые популярные вопросы клиентов. С
								большой вероятностью в нем можно найти решение. Но если не получилось, то
								специалисты ifu.com.ua рекомендуют обратиться в службу поддержки. Для связи есть
								электронная почта support@joker.win, онлайн-чат и мессенджеры. Ответ приходит в
								течение часа. Точное время зависит от загруженности менеджера.
							</p>
							<h2 class="ez-toc-section" id="-mirror11">Преимущества и недостатки</h2>
							<p>
								Специалисты ifu.com.ua выделили такие преимущества Джокер Казино:
							</p>
							<ul>
								<li>лицензированный софт;</li>
								<li>широкий ассортимент азартных развлечений;</li>
								<li>наличие мобильного приложения;</li>
								<li>качественный и удобный в использовании софт;</li>
								<li>круглосуточная поддержка игроков.</li>
							</ul>
							<p>
								Из недостатков необходимо отметить то, что владельцы iPhone не могут
								использовать скачиваемое мобильное приложение.
							</p>
							<h3 class="ez-toc-section" id="-mirror11.1">Отзывы игроков </h3>
							<p>
								О Joker Casino отзывы в основном положительные. Клиенты
								выбирают это казино благодаря тому, что оно имеет хорошую репутацию на рынке.
								Оператор считается честным, безопасным и надежным, он работает на основании
								лицензии Кюрасао. Этот документ защищает права игроков.
							</p>
							<p>
								Клиенты отмечают качественный и лицензированный софт. Ассортимент учитывает
								потребности разных гемблеров. Поэтому у каждого есть возможность хорошо провести
								время на сайте.
							</p>
							<p>
								Современные гемблеры начали активно использовать мобильную версию сайта и
								скачиваемое приложение. Они отмечают, что дополнительный софт является удобным в
								использовании и не ограничивает их возможности. Через него можно делать ставки в
								любой удобный момент.
							</p>
						</div>
						<div itemscope itemtype="https://schema.org/FAQPage">
							<h2 class="ez-toc-section" id="-mirror12">FAQ</h2>
							<p>Новый ресурс Casino Joker вызывает много вопросов у игроков. На самые популярные ответы представлены ниже.</p>
							<div class="faq-blk" itemprop="mainEntity" itemscope itemtype="https://schema.org/Question">
								<h3 id="-mirror12.1" itemprop="name">Как играть в Joker Casino</h3>
								<div itemprop="acceptedAnswer" itemscope itemtype="https://schema.org/Answer">
									<div itemprop="text">
										<p>
											В первую очередь необходимо выполнить на Джокер Казино вход в личный
											кабинет по логину и паролю. После этого нужно проверить баланс и
											пополнить его, если нет средств для ставок. Следующий шаг — это изучение
											каталога игр. Их там много, поэтому можно воспользоваться сортировкой и
											поисковой строкой. Когда слот найден, его нужно протестировать в демо-режиме, а
											затем запустить в полном. Внутри слота есть функциональная панель с кнопками, с
											помощью которой можно делать ставки.
										</p>
									</div>
								</div>
							</div>
							<div class="faq-blk" itemprop="mainEntity" itemscope itemtype="https://schema.org/Question">
								<h3 id="-mirror12.2" itemprop="name">Как вывести деньги с Joker Casino?</h3>
								<div itemprop="acceptedAnswer" itemscope itemtype="https://schema.org/Answer">
									<div itemprop="text">
										<p>
											Вывести деньги с Joker Win Casino можно через кассу в личном
											кабинете. Для кэшаута можно использовать банковские карты и электронные
											кошельки. Минимальная сумма вывода — 100 гривен. Операция занимает от нескольких
											часов до 3-х дней, что зависит от выбранной платежной системы.
										</p>
									</div>
								</div>
							</div>
							<div class="faq-blk" itemprop="mainEntity" itemscope itemtype="https://schema.org/Question">
								<h3 id="-mirror12.3" itemprop="name">Есть в Joker Casino демонстрационный режим?</h3>
								<div itemprop="acceptedAnswer" itemscope itemtype="https://schema.org/Answer">
									<div itemprop="text">
										<p>
											На Джокер игровые автоматы можно запускать в демо-версии. Он не
											требует ни регистрации, ни депозита. Ставки можно делать на виртуальные монеты,
											которые уже есть на балансе слота.
										</p>
									</div>
								</div>
							</div>
							<div class="faq-blk" itemprop="mainEntity" itemscope itemtype="https://schema.org/Question">
								<h3 id="-mirror12.4" itemprop="name">Как получить бонус за регистрацию</h3>
								<div itemprop="acceptedAnswer" itemscope itemtype="https://schema.org/Answer">
									<div itemprop="text">
										<p>
											Все новые клиенты получают от казино Джокер бонус за регистрацию.
											Для этого нужно пройти регистрацию и сделать первый денежный взнос.
											Размер приветственного подарка зависит от суммы депозита:
										</p>
										<ul>
											<li>100 гривен — 247 фриспинов;</li>
											<li>150 гривен — 100% на депозит и 147 фриспинов;</li>
											<li>250 — 150% на депозит и 147 фриспинов.</li>
										</ul>
										<p>
											Для вывода бонус нужно отыграть.
										</p>
									</div>
								</div>
							</div>
						</div>
						<!--seo-text-end-->
					</div>
				</div>
				<footer class="page-footer">
					<div class="container">
						<div class="columns is-column-reverse-mobile">
							<div class="column text-center is-6 mt-16 mt-md-0">
								<p class="mb-16">18+ Азартные игры могут вызывать зависимость.</p>
								<p class="mb-16">© 2020 Все права защищены.</p>
							</div>
						</div>
					</div>
				</footer>
      <script>
         function downloadJSAtOnload() {
            setTimeout(downloadJSAtOnloadScript, 2000);
         };
         function downloadJSAtOnloadScript() {
            var element = document.createElement("script");
            element.src = "wp-content/themes/js/cstm.js";
            document.body.appendChild(element);
         }
         if (window.addEventListener)
            window.addEventListener("load", downloadJSAtOnload, false);
         else if (window.attachEvent)
            window.attachEvent("onload", downloadJSAtOnload);
         else
            window.onload = downloadJSAtOnload;
      </script>
      <!-- * jquery lib -->
      <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.0.0/jquery.min.js"></script>
      <!-- * Переключатель динамического контента  -->
      <script>
         $(".head-cas-block .tab").click(function () {
            $(".head-cas-block .tab").removeClass("active").eq($(this).index()).addClass("active");
            $(".tab_item").hide().eq($(this).index()).fadeIn()
         }).eq(0).addClass("active");
      </script>
      <!-- * Копирование с выдилением на data-target -->
      <script>
         function selectText(id) {
            var sel, range;
            var el = document.getElementById(id); //get element id
            if (window.getSelection && document.createRange) { //Browser compatibility
               sel = window.getSelection();
               if (sel.toString() == '') { //no text selection
                  window.setTimeout(function () {
                     range = document.createRange(); //range object
                     range.selectNodeContents(el); //sets Range
                     sel.removeAllRanges(); //remove all ranges from selection
                     sel.addRange(range);//add Range to a Selection.
                  }, 1);
               }
            } else if (document.selection) { //older ie
               sel = document.selection.createRange();
               if (sel.text == '') { //no text selection
                  range = document.body.createTextRange();//Creates TextRange object
                  range.moveToElementText(el);//sets Range
                  range.select(); //make selection.
               }
            }
         }

         var tooltip = '<span class="tooltiptext" id="tooltiptext">\u0421\u043A\u043E\u043F\u0438\u0440\u043E\u0432\u0430\u043D\u043E!</span>';

         copy_btn_1.onclick = copy_btn_2.onclick = copy_btn_3.onclick = function () {
            selectText(this.dataset.targetCopyId);
            this.parentElement.insertAdjacentHTML('beforeend', tooltip);
            setTimeout(() => document.execCommand("copy"));
            setTimeout(function () {
               document.getElementsByClassName("tooltiptext")[0].remove();
            }, 4000);
         }
      </script>
   </body>
</html>